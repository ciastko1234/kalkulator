# Kalkulator poświadczeń — GitHub Pages

Gotowa statyczna strona do publikacji na GitHub Pages.

## Publikacja

1. Utwórz nowe repozytorium na GitHubie, np. `poswiadczenia`.
2. Wgraj do głównego katalogu repozytorium pliki:
   - `index.html`
   - `.nojekyll`
3. Wejdź w **Settings → Pages**.
4. W sekcji **Build and deployment** wybierz:
   - **Source:** `Deploy from a branch`
   - **Branch:** `main`
   - folder: `/ (root)`
5. Kliknij **Save**.
6. Po chwili GitHub poda publiczny adres strony.

## Ważne

Ta wersja zapisuje dane lokalnie w przeglądarce (`localStorage`). Oznacza to, że każda osoba korzystająca ze strony ma własne dane na swoim urządzeniu/przeglądarce. GitHub Pages nie udostępnia wspólnej bazy danych.
